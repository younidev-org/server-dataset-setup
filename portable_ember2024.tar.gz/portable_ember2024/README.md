# Portable EMBER2024 PDF download and LightGBM training

Copy this entire folder to your server. It bundles the upstream EMBER2024
Python source and license, so the original checkout is not needed.
Dependencies are installed from PyPI; network access is required for setup
and downloading data. Use Python 3.10 or newer on Linux.

## Install on the server

Run from inside this folder:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

LightGBM needs the system OpenMP runtime. On Debian/Ubuntu, if importing
LightGBM reports a missing `libgomp.so.1`, install it with:

```bash
sudo apt-get install libgomp1
```

## 1. Download PDF training data only

```bash
python download_pdf.py
```

Downloads and extracts `PDF_train.zip` from `joyce8/EMBER2024` into
`data/PDF/`. This contains precomputed features and binary labels,
not original PDF documents. No test/challenge data or pretrained models
are downloaded. Hugging Face cache stays in `.cache/huggingface/` and
Xet is disabled by default, matching the working download workaround.
Public downloads do not require a Hugging Face token.
Running again can download/extract the archive again.

## 2. Train

```bash
python train.py
```

Finds all `*_train.jsonl` files recursively under `data/`, vectorizes them
using the bundled upstream feature extractor, then trains one binary
LightGBM model (0 = benign, 1 = malicious). Rows labeled null or -1 are
skipped; other labels are rejected. Both classes must be present.
All training rows are used. Test and challenge JSONL filenames are
excluded. No holdout evaluation or accuracy estimate is performed.

To include ELF or another type, add its **EMBER2024 training JSONL files**
anywhere under `data/`, then run `python train.py` again:

```text
data/
  PDF/2023-09-24_2023-09-30_PDF_train.jsonl
  ELF/2023-09-24_2023-09-30_ELF_train.jsonl
```

Nested layouts such as `data/train/PDF/` also work. Keep the official
`_train.jsonl` suffix. Raw PDF/ELF binaries are not training inputs.
Adding files retrains from scratch; it does not update the existing model
incrementally. Do not add duplicate copies of the same dataset files,
and finish downloading before starting training.

Outputs (replaced on each successful training run):

- `output/model.txt`: trained LightGBM model.
- `output/training.json`: selected files, labeled row count, class counts,
  feature count, and requested boosting rounds.

Optional paths and CPU limits:

```bash
python download_pdf.py --data-dir /srv/ember/data
python train.py --data-dir /srv/ember/data --output-dir /srv/ember/output --threads 8 --rounds 500
```

Defaults resolve relative to the scripts, so scripts can be launched from
any working directory. The default is 500 boosting rounds and all CPU cores.
Vectors use temporary disk-backed storage in the output folder (about
10 KB per labeled row), removed afterward. LightGBM still needs RAM for
training; memory requirements grow with the dataset.

## Tests

```bash
python -m unittest discover -v
```

Tests run a small real LightGBM fit on generated EMBER feature records,
check recursive discovery and exclusion of held-out data, and exercise
PDF extraction using a local ZIP instead of a network download.

Vendored upstream commit: `0ef753e81d98bf209f71b03cd331dfc190b5b54d`.
Source: https://github.com/FutureComputing4AI/EMBER2024
Signify 0.8.1 is selected because this upstream source imports
`SignedPEFile`, removed in Signify 0.9.
